/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package go_football;

//import static go_football.Playground_owner.pgs;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.util.Date;
import java.text.ParseException;
import java.util.ArrayList;

/**
 *class to take playground data and show playground
 * @author vip
 */
public class Playground {
    Scanner input=new Scanner(System.in);
    protected String name;
    protected String size;
    protected int available_from;
    protected int available_to;
    int []av;
    protected double price_per_hour;
    protected String cancellation_period;
    protected boolean Active=false;
    protected int number_location;
    protected String Street_location;
    protected String Management_location;
    protected String Governorate_location;
    
    void Add_playground()
    {
        System.out.println("Enter PlayGround Name :");
        name=input.next();
        System.out.println("Enter PlayGround Size :");
        size=input.next();
        System.out.println("Enter PlayGround Price Per Hour :");
        price_per_hour=input.nextDouble();
        this.Set_date();
        System.out.println("Enter PlayGround Location: example\"12 ahmedzewzl dokki giza\"");
        number_location=input.nextInt();
        Street_location=input.next();
        Management_location=input.next();
        Governorate_location=input.next();
        System.out.println("Enter cancellation period");
        input.next();
        cancellation_period=input.nextLine();        
    }
    public void Set_date()
    {
           Scanner input=new Scanner(System.in);
           System.out.println("The playground is available From ... \"with 24 hour format\" ");
           available_from=input.nextInt();
           System.out.println("The playground is available To ... \"with 24 hour format\" ");
           available_to=input.nextInt();
           av=new int[(available_to-available_from)];
           for(int i=0;i<(available_to-available_from);i++)
           {
               av[i]=0;
           }
    }

    void Show_playground()
    {
            System.out.print("PlayGround Name: "+this.name);
            System.out.print("\tPlayGround Price: "+this.price_per_hour);
            System.out.print("\tPlayGround Location: "+this.number_location);
            System.out.print(" "+this.Street_location);
            System.out.print(" "+this.Management_location);
            System.out.println(" "+this.Governorate_location);
//            System.out.println("the statue of playground is : "+Active);
    }
    void Show_playgrounds()
    {
            
            System.out.print("-PlayGround Name: "+name);
            System.out.print("\tPlayGround Price: "+price_per_hour);
            System.out.print("\tPlayGround Location: "+number_location);
            System.out.print(" "+Street_location);
            System.out.print(" "+Management_location);
            System.out.print(" "+Governorate_location);
            System.out.println("\tthe statue of playground is : "+Active);
    }
}
