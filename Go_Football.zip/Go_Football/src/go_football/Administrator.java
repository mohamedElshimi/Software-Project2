/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package go_football;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *class to do all option to Administrator
 * @author vip
 */
public class Administrator extends User{
    Scanner input=new Scanner(System.in);
    
    
    
    public Administrator() {
        Name="mohamed";
        ID=2020;
        String s="mohamed@gmail.com";
        Email=s.toCharArray();
        Password="mohamed";
        location="12 ahmed zewel street dokki";
        role="admin";
    }
    /**
     * 
     * @param pp arrayList of class playground 
     */
     void Show_Allplaygrounds(ArrayList<Playground_owner>pp)
    {
        for(int i=0;i<pp.size();i++)
        {
            Playground_owner o=new Playground_owner();
            o=pp.get(i);
            for(int j=0;j<o.pgs.size();j++)
            {
                    Playground p=new Playground();
                    p=o.pgs.get(j);
                    p.Show_playground();
            }
        }
    }
     /**
      * 
      * @param pp arrayList of class User 
      */
      void Show_Alluser(ArrayList<User>pp)
    {
            
            for(int i=1;i<pp.size();i++)
            {
                User o=new User();
                o=pp.get(i);
                o.Show_Data();
            }
    }
      /**
       * 
       * @param pp arrayList of class Playground_owner 
       */
    void Approve_playground(ArrayList<Playground_owner>pp)
    {
        int z=1;
        ArrayList<Playground> p1=new ArrayList<Playground>();
        for(int i=0;i<pp.size();i++)
        {
            Playground_owner o=new Playground_owner();
            o=pp.get(i);
            for(int j=0;j<o.pgs.size();j++)
            {
                Playground p=new Playground();
                p=o.pgs.get(j);
                if(!p.Active)
                {
                    System.out.print(z);
                    p.Show_playgrounds();
                    p1.add(p);
                }
                z++;
            }
        }
        System.out.println("Enter number of playground ");
        Scanner input=new Scanner(System.in);
        int ch=input.nextInt();
        Playground a=new Playground();
        a=p1.get((ch-1));
        System.out.println("1-Approve\n2-Not approve");
        int c=input.nextInt();
        if(c==1)
        {
            a.Active=true;
            p1.remove((ch-1));
            System.out.println("Playground avtivate");
        }
        else
        {
          for(int i=0;i<pp.size();i++)
            {
                Playground_owner o=new Playground_owner();
                o=pp.get(i);
                for(int j=0;j<o.pgs.size();j++)
                {
                    Playground p=new Playground();
                    p=o.pgs.get(j);
                    if(p.equals(a))
                    {
                        
                        o.pgs.remove(j);
                    }
                }
            }  
        }
    }
    
    /**
     * 
     * @param pp arrayList of class Playground_owner
     */
    void Delete_playground(ArrayList<Playground_owner>pp)
    {
        ArrayList<Playground> p1=new ArrayList<Playground>();
        int z=1;
        for(int i=0;i<pp.size();i++)
        {
            Playground_owner o=new Playground_owner();
            o=pp.get(i);
            for(int j=0;j<o.pgs.size();j++)
            {
                Playground p=new Playground();
                p=o.pgs.get(j);
                System.out.print(z);
                p.Show_playgrounds();
                p1.add(p);
                z++;
            }
        }
        System.out.println("Enter number of playground....");
        Scanner input=new Scanner(System.in);
        int ch=input.nextInt();
        Playground a=new Playground();
        a=p1.get((ch-1));
         for(int i=0;i<pp.size();i++)
            {
                Playground_owner o=new Playground_owner();
                o=pp.get(i);
                for(int j=0;j<o.pgs.size();j++)
                {
                    Playground p=new Playground();
                    p=o.pgs.get(j);
                    if(p.equals(a))
                    {
                        o.pgs.remove(j);
                    }
                }
            }  
    }
    /**
     * 
     * @param pp arrayList of class Playground_owner
     */
    void Activate_playground(ArrayList<Playground_owner>pp)
    {
        ArrayList<Playground> p1=new ArrayList<Playground>();
        int z=1;
        for(int i=0;i<pp.size();i++)
        {
            Playground_owner o=new Playground_owner();
            o=pp.get(i);
            for(int j=0;j<o.pgs.size();j++)
            {
                Playground p=new Playground();
                p=o.pgs.get(j);
                if(!p.Active)
                {
                    System.out.print(z);
                    p.Show_playgrounds();
                    p1.add(p);
                }
                z++;
            }
        }
        System.out.println("Enter number of playground that want to activate");
        Scanner input=new Scanner(System.in);
        int ch=input.nextInt();
        Playground a=new Playground();
        a=p1.get((ch-1));
        a.Active=true;
        System.out.println("Playground is avtivate");
        p1.clear();
   }
    
    
    
    /**
     * 
     * @param pp arrayList of class Playground_owner
     */
    void Suspend_playground(ArrayList<Playground_owner>pp)
    {
        ArrayList<Playground> p1=new ArrayList<Playground>();
        int z=1;
        for(int i=0;i<pp.size();i++)
        {
            Playground_owner o=new Playground_owner();
            o=pp.get(i);
            for(int j=0;j<o.pgs.size();j++)
            {
                Playground p=new Playground();
                p=o.pgs.get(j);
                if(p.Active)
                {
                    System.out.print(z);
                    p.Show_playgrounds();
                    p1.add(p);
                }
                z++;
            }
        }
        System.out.println("Enter number of playground that want to activate");
        Scanner input=new Scanner(System.in);
        int ch=input.nextInt();
        Playground a=new Playground();
        a=p1.get((ch-1));
        a.Active=false;
        System.out.println("Playground is Suspend");
    }
   
    
}
