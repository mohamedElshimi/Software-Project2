/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package go_football;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
/**
 * project go_Football
 * @author vip
 */
public class Go_Football {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int indofuser=1;
        Scanner input=new Scanner(System.in);
        ArrayList<Playground_owner>pgos=new ArrayList<Playground_owner>();
        ArrayList<Player>ps=new ArrayList<Player>();
        ArrayList<User>users=new ArrayList<User>();
        Administrator a=new Administrator();
        users.add(a);
        char end='n';
        do
        {
            int z=0;
            z=Welcome_menu(indofuser,users,pgos,ps);
            continue_login(z,users,pgos,ps,a);
        }while(end=='n');
    }
    /**
     *  Welcome menu to show welcome menu 
     * @param in variable to catch index in user arrayList it catch in login page
     * @param us arrayList of class User
     * @param pg arrayList of class Playground_owner
     * @param p1 arrayList of class Player
     * @return in integer index in user arrayList
     */
    public static int Welcome_menu(int in,ArrayList<User>us,ArrayList<Playground_owner>pg,ArrayList<Player>p1)
    {
        Scanner input=new Scanner(System.in);
        System.out.println("Welcome Go_Football");
        System.out.println("1-Register as new user");
        System.out.println("2-login");
        int ch=input.nextInt();
        switch(ch)
        {
            case 1:
            {
                User u=new User();
                u.Registering();
                us.add(u);
                in=Check_Login(in,us,pg,p1);
                break;
            }
            case 2:
            {
                in=Check_Login(in,us,pg,p1);
            }
        }
        return in;
    }
    /**
     * Check login to check if e-mail and password correct or not
     * @param in variable to catch index in user
     * @param us arrayList of class User
     * @param pg arrayList of class Playground_owner
     * @param p1 arrayList of class Player
     * @return z integer index user in user arrayList return to welcome page
     */
     public static int Check_Login(int in,ArrayList<User>us,ArrayList<Playground_owner>pg,ArrayList<Player>p1)
    {
        in=0;
        Scanner input=new Scanner(System.in);
        char[] E;
        String P;
        boolean cat=false;
        System.out.println("Enter your Email");
        E=input.next().toCharArray();
        System.out.println("Enter Your Password ");
        P=input.next();
        int z=0;
        for(;z<us.size();z++)
        {
            User w=new User();
            w=us.get(z);
            cat=Arrays.equals(w.Email, E);
            if(cat==true)
            {
                if(P.equalsIgnoreCase(w.Password))
                {
                    cat=true;
                    break;
                }
                else
                    cat=false;
            }
            
        }
        if(cat==false)
        {
            System.out.println("Your E-mail or Password is incorrect");
            Check_Login(in,us,pg,p1);
        }
        return z;
    }
     /**
      * continue login to make user role
      * @param in index of user in user arrayList
      * @param us ArrayList of class User
      * @param pg ArrayList of class Playground_owner
      * @param p1 ArrayList of class Player
      * @param a object of class Administrator
      */
     public static void continue_login(int in,ArrayList<User>us,ArrayList<Playground_owner>pg,ArrayList<Player>p1,Administrator a)
     {
         Scanner input=new Scanner(System.in);
         System.out.println("Welcome to our application");
         System.out.println("1-create profile");
         System.out.println("2-Login as playground owner");
         System.out.println("3-Login as player");
         if(in==0)
         {
            System.out.println("4-Login to administration page");//This option will appear only to the admin who login with the correct email and password
         }
         int d=input.nextInt();
        switch(d)
        {
                case 1:
                {
                    User u=new User();
                    u=us.get(in);
                    u.role="playground owner";
                    Playground_owner o=new Playground_owner(u);
                    o.Create_profile();
                    pg.add(o);
                    pgo_menu(o,in,us,pg,p1,a);
                    break;

                }
                case 2:
                {
                    User u=new User();
                    u=us.get(in);
                    Playground_owner o=new Playground_owner(u);
                    pg.add(o);
                    pgo_menu(o,in,us,pg,p1,a);
                    
                    break;
                }
                case 3:
                {
                    User u=new User();
                    u=us.get(in);
                    u.role="player";
                    Player p=new Player(u);
                    p1.add(p);
                    player_menu(p,in,us,pg,p1,a);
                    break;
                }
                case 4:
                {
                    admin_menu(in,us,pg,p1,a);
                    break;
                }
            }
     }
     /**
      * pgo menu to show and do playground owner option
      * @param in index of user in user arrayList
      * @param o object of class Player
      * @param us ArrayList of class User
      * @param pg ArrayList of class Playground_owner
      * @param p1 ArrayList of class Player
      * @param a object of class Administrator
      */
     public static void pgo_menu(Playground_owner o,int in,ArrayList<User>us,ArrayList<Playground_owner>pg,ArrayList<Player>p1,Administrator a)
     {
         Scanner input=new Scanner(System.in);
         System.out.println("1-Add playground");
         System.out.println("2-Update Playgroung information");
         System.out.println("3-View bookings");
         System.out.println("4-Check eWallet");
         System.out.println("5-back");
         System.out.println("6-log out");
         System.out.println("Enter your choice");
         int ch=input.nextInt();
         switch(ch)
         {
             case 1:
             {
                 Playground pl=new Playground();
                 pl.Add_playground();
                 o.pgs.add(pl);
                  pgo_menu(o,in,us,pg,p1,a);
                 break;
             }
             case 2:
             {
                 o.Update_playground_info();
                  pgo_menu(o,in,us,pg,p1,a);
                 break;
             }
             case 3:
             {
                 
                  pgo_menu(o,in,us,pg,p1,a);
                 break;
             }
             case 4:
             {
                 System.out.println("you have : "+o.Check_eWallet());
                  pgo_menu(o,in,us,pg,p1,a);
                  break;
             }
             case 5:
             {
                 continue_login(in,us,pg,p1,a);
                 break;
             }
             case 6:
             {
                 break;
             }
             default:
             {
                 System.out.println("enter correct choice ");
                 pgo_menu(o,in,us,pg,p1,a);
                 
             }
         }

     }
     /**
      * player menu to show and do playground owner option
      * @param in index of user in user arrayList
      * @param o object of class Player
      * @param us ArrayList of class User
      * @param pg ArrayList of class Playground_owner
      * @param p1 ArrayList of class Player
      * @param a object of class Administrator
      */
     public static void player_menu(Player o,int in,ArrayList<User>us,ArrayList<Playground_owner>pg,ArrayList<Player>p1,Administrator a)
     {
         Scanner input=new Scanner(System.in);
         System.out.println("1-Veiw available Playground");
         System.out.println("2-Book Playground");
         System.out.println("3-Create team");
         System.out.println("4-Send invitation");
         System.out.println("5-Edit player information");
         System.out.println("6-View playing hours");
         System.out.println("7-back");
         System.out.println("8-log out");
         System.out.println("Enter your choice");
         int ch=input.nextInt();
         switch(ch)
         {
             case 1:
             {
               o.View_playgrounds(pg);
               System.out.println("1-to filter");
               System.out.println("2-to back");
               int c=input.nextInt();
               if(c==1)
               {
                   o.Filter_playgrounds(pg);
                   player_menu(o,in,us,pg,p1,a);
               }
               else
               {
                    player_menu(o,in,us,pg,p1,a);
               }
               break;
             }
             case 2:
             {
                 o.Book_playground(pg);
                  player_menu(o,in,us,pg,p1,a);
                  break;
             }
             case 3:
             {
                 o.Create_Team();
                  player_menu(o,in,us,pg,p1,a);
                  break;
             }
             case 4:
             {
                 o.Send_invetation();
                  player_menu(o,in,us,pg,p1,a);
                  break;
             }
             case 5:
             {
                 o.Edit_player_info();
                  player_menu(o,in,us,pg,p1,a);
                  break;
             }
             case 6:
             {
                  player_menu(o,in,us,pg,p1,a);
                  break;
             }
             case 7:
             {
                 continue_login(in,us,pg,p1,a);
                 break;
             }
             case 8:
             {
                 break;
             }
             default:
             {
                 System.out.println("enter correct choice ");
                 player_menu(o,in,us,pg,p1,a);
             }
         }
     }
     /**
      * admin menu to show and do playground owner option
      * @param in index of user in user arrayList
      * @param us ArrayList of class User
      * @param pg ArrayList of class Playground_owner
      * @param p1 ArrayList of class Player
      * @param a object of class Administrator
      */
     public static void admin_menu(int in,ArrayList<User>us,ArrayList<Playground_owner>pg,ArrayList<Player>p1,Administrator a)
     {
         Scanner input=new Scanner(System.in);
         System.out.println("1-Show all users");
         System.out.println("2-Show all playgrounds");
         System.out.println("3-Show requests of playground");
         System.out.println("4-Suspend palyground");
         System.out.println("5-Delete playground");
         System.out.println("6-Activate playground");
         System.out.println("7-back");
         System.out.println("8-log out");
         System.out.println("Enter your choice");
         int ch=input.nextInt();
         switch(ch)
         {
             case 1:
             {
                 a.Show_Alluser(us);
                 admin_menu(in,us,pg,p1,a);
                 break;
             }
             case 2:
             {
                 a.Show_Allplaygrounds(pg);
                 admin_menu(in,us,pg,p1,a);
                 break;
             }
             case 3:
             {
                 a.Approve_playground(pg);
                 admin_menu(in,us,pg,p1,a);
                 break;
             }
             case 4:
             {
                 a.Suspend_playground(pg);
                 admin_menu(in,us,pg,p1,a);
                 break;
             }
             case 5:
             {
                 a.Delete_playground(pg);
                 admin_menu(in,us,pg,p1,a);
                 break;
             }
             case 6:
             {
                 a.Activate_playground(pg);
                 admin_menu(in,us,pg,p1,a);
                 break;
             }
             case 7:
             {
                 continue_login(in,us,pg,p1,a);
                 break;
             }
             case 8:
             {
                 break;
             }
             default:
             {
                 System.out.println("Enter from choice");
                 admin_menu(in,us,pg,p1,a);
             }
         }

     }
}
