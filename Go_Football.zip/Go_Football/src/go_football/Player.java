/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package go_football;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *class to do option for player
 * @author vip
 */
public class Player extends User{
    ArrayList<String> nameoteam =new ArrayList<String>();
    ArrayList<String> emailoteam =new ArrayList<String>();
    
    
    public Player() {
    }
    

    public Player(User u) {
        Name = u.Name;
        ID = u.ID;
        Email = u.Email;
        Password = u.Password;
        Phone = u.Phone;
        location = u.location;
        role="player";
    }
    
    void Create_Team()
    {
        System.out.println("Enter number of team");
        int n=input.nextInt();
        for(int i=0;i<n;i++)
        {
            System.out.println("Enter name player no: "+(i+1));
            nameoteam.add(input.next());
            System.out.println("Enter E-mail player no: "+(i+1));
            emailoteam.add(input.next());
        }
        System.out.println("Your team was Created");
    }
    
    void Send_invetation()
    {
        System.out.println("Enter Your Mail");
        String s=input.next();
        System.out.println("1-Send to your team");
        System.out.println("2-Send to other player");
        int ch=input.nextInt();
        if(ch==1)
        {
            System.out.println("Your E-mail is sent");
        }
        else if(ch==2)
        {
            System.out.println("Enter number of player");
            int nn=input.nextInt();
            for(int j=0;j<nn;j++)
            {
                System.out.println("Enter name player: "+(j+1));
                String ss=input.next();
                System.out.println("Enter E-mail player: "+(j+1));
                String sm=input.next();
            }
            System.out.println("Your E-mail is sent");
        }
        else
        {
            System.out.println("enter valid choice");
            this.Create_Team();
        }
    }
    
    void Edit_player_info()
    {
        System.out.println("Enter new Name");
        this.Name=input.next();
        System.out.println("Enter new ID");
        this.ID=input.nextLong();
        this.ValidateDetails();
        System.out.println("Enter new Password");
        this.Password=input.next();
        System.out.println("Enter new Phone");
        this.Phone=input.nextLong();
        System.out.println("Enter new Location");
        input.next();
        this.location=input.nextLine();
    }
    
    
    void View_playgrounds(ArrayList<Playground_owner>pp)
    {
        for(int i=0;i<pp.size();i++)
        {
            Playground_owner o=new Playground_owner();
            o=pp.get(i);
            for(int j=0;j<o.pgs.size();j++)
            {
                    Playground p=new Playground();
                    p=o.pgs.get(j);
                    if(p.Active)
                    {
                        p.Show_playground();
                    }
            }
        }
    }
    /**
     * 
     * @param pp arrayList of Playground_owner
     */
    void Filter_playgrounds(ArrayList<Playground_owner>pp)
    {
        System.out.println("with which option want to filter");
        System.out.println("1-Management");
        System.out.println("2-Governorate");
        int ch=input.nextInt();
        if(ch==1)
        {
             System.out.println("Enter Management");
             String s=input.next();
             for(int i=0;i<pp.size();i++)
             {
                 Playground_owner o=new Playground_owner();
                 o=pp.get(i);
                 for(int j=0;j<o.pgs.size();j++)
                 {
                     Playground p=new Playground();
                     p=o.pgs.get(j);
                     if(s.equalsIgnoreCase(p.Management_location));
                     {
                         p.Show_playground();
                     }
                 }
             }
        }
        else if(ch==2)
        {
            System.out.println("Enter Governorate");
             String s=input.next();
             for(int i=0;i<pp.size();i++)
             {
                 Playground_owner o=new Playground_owner();
                 o=pp.get(i);
                 for(int j=0;j<o.pgs.size();j++)
                 {
                     Playground p=new Playground();
                     p=o.pgs.get(j);
                     if(s.equalsIgnoreCase(p.Governorate_location));
                     {
                         p.Show_playground();
                     }
                 }
             }
        }
        else
        {
            System.out.println("enter valid choice");
            Filter_playgrounds(pp);
        }
    }
    /**
     * 
     * @param pp arrayList of class Playground_owner
     */
    void Book_playground(ArrayList<Playground_owner>pp)
    {
        
        ArrayList<Playground> p1=new ArrayList<Playground>();
        int z=1;
        for(int i=0;i<pp.size();i++)
        {
            Playground_owner o=new Playground_owner();
            o=pp.get(i);
            for(int j=0;j<o.pgs.size();j++)
            {
                Playground p=new Playground();
                p=o.pgs.get(j);
                if(p.Active)
                {
                    System.out.print(z);
                    p.Show_playgrounds();
                    p1.add(p);
                    z++;
                }
                
            }
        }
        System.out.println("Enter number of playground ");
        Scanner input=new Scanner(System.in);
        int ch=input.nextInt();
        Playground a=new Playground();
        a=p1.get((ch-1));
        int i=0;
        for(;i<a.av.length;i++)
        {
            if(a.av[i]==0)
                System.out.println((i+1)+" ["+(ch)+":"+(ch+1)+"]");
            ch++;
        }
        System.out.println("Enter your choice ");
        int c=input.nextInt();
        a.av[(c-1)]=1;
    }
    
}
