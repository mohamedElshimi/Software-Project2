/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package go_football;
import java.util.Scanner;
import java.util.ArrayList;
/**
 * class to create user
 * @author vip
 */
public class User {
    Scanner input=new Scanner(System.in);
    protected String Name;
    protected long ID;
    protected char[] Email=new char[20];
    protected String Password;
    protected long Phone;
    protected String location;
    protected String role;
    protected long eWallet_id;
    protected String eWallet_password;
    protected double eWallet_value=1000;
    

    public User() {
    }
    
    public void Registering()
    {
        System.out.println("Enter your Name");
        Name=input.next();
        System.out.println("Enter your ID");
        ID=input.nextLong();
        this.ValidateDetails();
        System.out.println("Enter your Password");
        Password=input.next();
        System.out.println("Enter your Phone");
        Phone=input.nextLong();
        System.out.println("Enter your Location");
        input.next();
        location=input.nextLine();
        System.out.println("wait we will send a verification code to your Email");
        System.out.println("Enter your code to sign up");
        String s;
        s=input.next();
        System.out.println("Done");
        
    }
    public void Show_Data()
    {
        System.out.print(" Name is : "+Name);
        System.out.print("\t ID is : "+ID);
        System.out.print("\t Phone is : "+Phone);
        System.out.println("\t role  is : "+role);
    }
    public void ValidateDetails()
    {
        System.out.println("Enter your E-mail");
        Scanner input=new Scanner(System.in);
        Email=input.next().toCharArray();
        for(int i=0;i<Email.length;i++)
        {
            if(Email[i]=='@')
            {
                for(int j=0;j<Email.length;j++)
                {
                        if(Email[j]=='.')
                        {
                            return;
                        }
                }
            }
        }
        System.out.println("Please enter valid E-mail");
        this.ValidateDetails();
    }
    /**
     * @return double eWallet value
     */
    double Check_eWallet()
    {
        return eWallet_value;
    }
    /**
     * @param t The price of the playground being reserved
     * @param id id for person who want to user eWallet
     * @param pass password of eWallet
     */
    void Transfer(long id,String pass,double t)
    {
        if(eWallet_id==id&&pass.equalsIgnoreCase(this.eWallet_password))
        {
            eWallet_value-=t;
        }
    }
}
