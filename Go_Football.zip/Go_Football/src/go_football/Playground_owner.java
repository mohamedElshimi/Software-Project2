/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package go_football;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *class to do option for playground owner
 * @author vip
 */
public class Playground_owner extends User{
    ArrayList<Playground> pgs=new ArrayList<Playground>();

    public Playground_owner() {
    }   
    
    
    public Playground_owner(User u) {
        Name = u.Name;
        ID = u.ID;
        Email = u.Email;
        Password = u.Password;
        Phone = u.Phone;
        location = u.location;
        role="pgo";
    }
   
    void Create_profile()
    {
        Scanner input=new Scanner(System.in);
        System.out.println("Enter your E-mail");
        char[]email=input.next().toCharArray();
        System.out.println("Enter your phone mobile");
        long ph=input.nextLong();
        System.out.println("Enter verification code");
        String w=input.next();
        System.out.println("Done you now can add your playground");
        role="playground";
    }
    
    void Update_playground_info()
    {
        int z=1;
        Playground p=new Playground();
        for(int i=0;i<this.pgs.size();i++)
        {
            p=this.pgs.get(i);
            System.out.println(z);
            p.Show_playgrounds();
            z++;
        }
        System.out.println("choose from your playgrounds");
        int ch=input.nextInt();
        p=pgs.get((ch-1));
        p.Add_playground();
    }
    
    void View_booking()
    {
        for(int i=0;i<this.pgs.size();i++)
        {
            Playground q=new Playground();
            q=pgs.get(i);
            System.out.println(i+1);
            q.Show_playgrounds();
        }
        System.out.println("Enter num of playground");
        int c=input.nextInt();
        Playground q=new Playground();
        q=pgs.get((c-1));
        for(int i=0;i<q.av.length;i++)
        {
            if(q.av[i]==1)
            {
                System.out.println("["+(c-1+q.available_from)+":"+(c+q.available_from));
                c++;
            }
        }
    }
    
    
}
